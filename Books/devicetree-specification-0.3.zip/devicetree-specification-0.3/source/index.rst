.. Devicetree Specification documentation master file, created by
   sphinx-quickstart on Tue Apr 19 10:28:32 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Devicetree Specification's documentation!
====================================================

.. toctree::
   :numbered:
   :maxdepth: 3

   license
   acknowledgements
   revhistory
   introduction
   devicetree-basics
   devicenodes
   device-bindings
   flattened-format
   source-language
   references

..
   Indices and tables
   ==================

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

